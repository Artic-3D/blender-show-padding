"""Cached GPU overlay and Blender lifecycle integration."""

from __future__ import annotations

import time

import bmesh
import bpy
import gpu
from bpy.app.handlers import persistent
from gpu.types import GPUShaderCreateInfo, GPUStageInterfaceInfo
from gpu_extras.batch import batch_for_shader

from .geometry import (
    build_overlay_geometry_with_template,
    compute_band_width,
    rebuild_overlay_geometry,
    state_signature,
)


_DRAW_HANDLE = None
_SHADER = None
_CACHE = {}
_REVISION = 1
_LAST_INVALIDATION = 0.0
_FALLBACK_INTERVAL = 30.0
_IDLE_VERIFY_DELAY = 0.5
_MAX_CACHE_ENTRIES = 8
_UPDATE_INTERVAL = 1.0 / 30.0
_IDLE_INTERVAL = 0.2
_REGISTERED = False


class _CacheEntry:
    __slots__ = (
        "batch",
        "revision",
        "signature",
        "last_signature_check",
        "last_geometry_update",
        "last_used",
        "stats",
        "templates",
        "band_width",
        "source_key",
        "selected_only",
        "uv_select_sync",
        "pending_positions",
        "pending_triangles",
        "needs_verify",
    )

    def __init__(self):
        self.batch = None
        self.revision = -1
        self.signature = None
        self.last_signature_check = 0.0
        self.last_geometry_update = 0.0
        self.last_used = 0.0
        self.stats = {}
        self.templates = ()
        self.band_width = None
        self.source_key = ()
        self.selected_only = False
        self.uv_select_sync = False
        self.pending_positions = None
        self.pending_triangles = None
        self.needs_verify = False


def tag_uv_editors_for_redraw():
    window_manager = getattr(bpy.context, "window_manager", None)
    if window_manager is None:
        return
    for window in window_manager.windows:
        for area in window.screen.areas:
            if area.type == "IMAGE_EDITOR":
                area.tag_redraw()


def invalidate_geometry(clear=False):
    global _REVISION, _LAST_INVALIDATION
    _REVISION += 1
    _LAST_INVALIDATION = time.monotonic()
    if clear:
        _CACHE.clear()
    _ensure_update_timer()
    tag_uv_editors_for_redraw()


def _source_objects(context):
    objects = getattr(context, "objects_in_mode_unique_data", None)
    if objects is None:
        view_layer = getattr(context, "view_layer", None)
        if view_layer is None:
            return []
        objects = [obj for obj in view_layer.objects if obj.mode == "EDIT"]
    result = []
    seen_meshes = set()
    for obj in objects:
        if obj.type != "MESH" or obj.mode != "EDIT":
            continue
        mesh = obj.data
        mesh_pointer = mesh.as_pointer()
        if mesh_pointer in seen_meshes:
            continue
        seen_meshes.add(mesh_pointer)
        result.append(obj)
    result.sort(key=lambda obj: obj.data.as_pointer())
    return result


def _source_objects_for_scene(scene):
    result = []
    seen_meshes = set()
    for obj in scene.objects:
        if obj.type != "MESH" or obj.mode != "EDIT":
            continue
        mesh = obj.data
        mesh_pointer = mesh.as_pointer()
        if mesh_pointer in seen_meshes:
            continue
        seen_meshes.add(mesh_pointer)
        result.append(obj)
    result.sort(key=lambda obj: obj.data.as_pointer())
    return result


def _collect_sources_for_scene(scene):
    sources = []
    for obj in _source_objects_for_scene(scene):
        mesh = obj.data
        active_uv = mesh.uv_layers.active
        if active_uv is None:
            continue
        try:
            bm = bmesh.from_edit_mesh(mesh)
        except (RuntimeError, ValueError):
            continue
        uv_layer = bm.loops.layers.uv.get(active_uv.name)
        if uv_layer is None:
            continue
        sources.append((mesh, bm, uv_layer, active_uv.name))
    return sources


def context_status(context):
    objects = _source_objects(context)
    if not objects:
        return "Enter mesh Edit Mode", "INFO"
    if not any(obj.data.uv_layers.active is not None for obj in objects):
        return "No active UV map", "INFO"
    settings = context.scene.uv_padding_overlay
    if settings.margin_px <= 0.0:
        return "Margin is zero", "INFO"
    if not settings.enabled:
        return "Overlay disabled", "HIDE_ON"
    return "Overlay active (50% opacity)", "CHECKMARK"


def _source_key(sources):
    return tuple(
        (mesh.as_pointer(), layer_name)
        for mesh, _bm, _uv_layer, layer_name in sources
    )


def _combined_signature(sources, selected_only, uv_select_sync):
    combined = 0xCBF29CE484222325
    for mesh, bm, uv_layer, layer_name in sources:
        value = state_signature(bm, uv_layer, selected_only, uv_select_sync)
        combined ^= mesh.as_pointer() & ((1 << 64) - 1)
        combined ^= hash(layer_name) & ((1 << 64) - 1)
        combined ^= value
        combined = (combined * 0x100000001B3) & ((1 << 64) - 1)
    return combined


def _rebuild_entry(entry, sources, band_width, selected_only, uv_select_sync):
    positions = []
    triangles = []
    combined_signature = 0xCBF29CE484222325
    aggregate = {
        "visible_faces": 0,
        "islands": 0,
        "boundary_edges": 0,
        "triangles": 0,
        "degenerate_edges": 0,
    }
    templates = []
    for mesh, bm, uv_layer, layer_name in sources:
        (
            local_positions,
            local_triangles,
            stats,
            signature,
            template,
        ) = build_overlay_geometry_with_template(
            bm, uv_layer, band_width, selected_only, uv_select_sync
        )
        templates.append(template)
        offset = len(positions)
        positions.extend(local_positions)
        triangles.extend(
            (a + offset, b + offset, c + offset)
            for a, b, c in local_triangles
        )
        for name in aggregate:
            aggregate[name] += stats[name]
        combined_signature ^= mesh.as_pointer() & ((1 << 64) - 1)
        combined_signature ^= hash(layer_name) & ((1 << 64) - 1)
        combined_signature ^= signature
        combined_signature = (
            combined_signature * 0x100000001B3
        ) & ((1 << 64) - 1)

    _queue_batch(entry, positions, triangles)
    entry.stats = aggregate
    entry.templates = tuple(templates)
    entry.band_width = band_width
    entry.signature = combined_signature
    entry.revision = _REVISION
    now = time.monotonic()
    entry.last_signature_check = now
    entry.last_geometry_update = now
    entry.needs_verify = False


def _queue_batch(entry, positions, triangles):
    entry.pending_positions = positions
    entry.pending_triangles = triangles


def _upload_pending_batch(entry):
    positions = entry.pending_positions
    triangles = entry.pending_triangles
    if positions is None or triangles is None:
        return
    entry.pending_positions = None
    entry.pending_triangles = None
    shader = _ensure_shader()
    if positions and triangles:
        entry.batch = batch_for_shader(
            shader,
            "TRIS",
            {"position": positions},
            indices=triangles,
        )
    else:
        entry.batch = None


def _refresh_entry(entry, sources, band_width):
    if len(entry.templates) != len(sources):
        return False
    positions = []
    triangles = []
    aggregate = {
        "visible_faces": 0,
        "islands": 0,
        "boundary_edges": 0,
        "triangles": 0,
        "degenerate_edges": 0,
    }
    try:
        for template, (_mesh, bm, uv_layer, _layer_name) in zip(
            entry.templates,
            sources,
        ):
            current_counts = (len(bm.verts), len(bm.edges), len(bm.faces))
            if template is None or current_counts != template.mesh_counts:
                return False
            local_positions, local_triangles, stats = rebuild_overlay_geometry(
                bm,
                template,
                uv_layer,
                band_width,
            )
            offset = len(positions)
            positions.extend(local_positions)
            triangles.extend(
                (a + offset, b + offset, c + offset)
                for a, b, c in local_triangles
            )
            for name in aggregate:
                aggregate[name] += stats[name]
    except (ReferenceError, RuntimeError, ValueError):
        return False
    _queue_batch(entry, positions, triangles)
    entry.stats = aggregate
    entry.band_width = band_width
    entry.revision = _REVISION
    entry.last_geometry_update = time.monotonic()
    entry.needs_verify = True
    return True


def _prune_cache():
    if len(_CACHE) <= _MAX_CACHE_ENTRIES:
        return
    oldest = sorted(_CACHE.items(), key=lambda item: item[1].last_used)
    for key, _entry in oldest[: len(_CACHE) - _MAX_CACHE_ENTRIES]:
        del _CACHE[key]


def _ensure_entry(scene, sources, band_width, selected_only, uv_select_sync):
    key = scene.as_pointer()
    entry = _CACHE.get(key)
    if entry is None:
        entry = _CacheEntry()
        _CACHE[key] = entry
    now = time.monotonic()
    entry.last_used = now
    source_key = _source_key(sources)
    configuration_changed = (
        entry.source_key != source_key
        or entry.selected_only != bool(selected_only)
        or entry.uv_select_sync != bool(uv_select_sync)
    )
    if entry.signature is None or configuration_changed:
        _rebuild_entry(
            entry,
            sources,
            band_width,
            selected_only,
            uv_select_sync,
        )
        entry.source_key = source_key
        entry.selected_only = bool(selected_only)
        entry.uv_select_sync = bool(uv_select_sync)
    elif entry.revision != _REVISION or entry.band_width != band_width:
        if not _refresh_entry(entry, sources, band_width):
            _rebuild_entry(
                entry,
                sources,
                band_width,
                selected_only,
                uv_select_sync,
            )
    should_verify_refresh = (
        entry.needs_verify
        and now - _LAST_INVALIDATION >= _IDLE_VERIFY_DELAY
    )
    should_run_fallback = (
        now - entry.last_signature_check >= _FALLBACK_INTERVAL
    )
    if should_verify_refresh or should_run_fallback:
        signature = _combined_signature(sources, selected_only, uv_select_sync)
        entry.last_signature_check = now
        if signature != entry.signature:
            _rebuild_entry(
                entry,
                sources,
                band_width,
                selected_only,
                uv_select_sync,
            )
        else:
            entry.needs_verify = False
    _prune_cache()
    return entry


def _ensure_shader():
    global _SHADER
    if _SHADER is not None:
        return _SHADER
    interface = GPUStageInterfaceInfo("uv_padding_overlay_interface")
    interface.smooth("VEC2", "uv_coordinate")
    info = GPUShaderCreateInfo()
    info.vertex_in(0, "VEC2", "position")
    info.push_constant("VEC4", "view_rect")
    info.push_constant("VEC4", "color")
    info.vertex_out(interface)
    info.fragment_out(0, "VEC4", "fragColor")
    info.vertex_source(
        """
        void main()
        {
            vec2 span = max(view_rect.zw - view_rect.xy, vec2(1e-20));
            vec2 unit_position = (position - view_rect.xy) / span;
            uv_coordinate = position;
            gl_Position = vec4(unit_position * 2.0 - 1.0, 0.0, 1.0);
        }
        """
    )
    info.fragment_source(
        """
        void main()
        {
            fragColor = color + vec4(uv_coordinate * 0.0, 0.0, 0.0);
        }
        """
    )
    _SHADER = gpu.shader.create_from_info(info)
    return _SHADER


def _draw_overlay():
    context = bpy.context
    area = context.area
    region = context.region
    space = context.space_data
    if (
        area is None
        or region is None
        or area.type != "IMAGE_EDITOR"
        or region.type != "WINDOW"
        or not (
            area.ui_type == "UV" or getattr(space, "ui_mode", "") == "UV"
        )
    ):
        return
    scene = context.scene
    settings = getattr(scene, "uv_padding_overlay", None)
    if settings is None or not settings.enabled or settings.margin_px <= 0.0:
        return
    entry = _CACHE.get(scene.as_pointer())
    if entry is None:
        return
    _upload_pending_batch(entry)
    if entry.batch is None:
        return
    entry.last_used = time.monotonic()
    view = region.view2d
    minimum = view.region_to_view(0, 0)
    maximum = view.region_to_view(region.width, region.height)
    shader = _ensure_shader()
    shader.bind()
    shader.uniform_float(
        "view_rect",
        (minimum[0], minimum[1], maximum[0], maximum[1]),
    )
    shader.uniform_float(
        "color",
        (
            float(settings.color[0]),
            float(settings.color[1]),
            float(settings.color[2]),
            0.5,
        ),
    )
    gpu.state.depth_test_set("NONE")
    gpu.state.blend_set("ALPHA")
    try:
        entry.batch.draw(shader)
    finally:
        gpu.state.blend_set("NONE")
        gpu.state.depth_test_set("NONE")


def _update_scene_cache(scene):
    """Read edit BMesh data outside viewport drawing and queue GPU geometry."""

    settings = getattr(scene, "uv_padding_overlay", None)
    if settings is None or not settings.enabled or settings.margin_px <= 0.0:
        _CACHE.pop(scene.as_pointer(), None)
        return False
    band_width = compute_band_width(
        settings.margin_px,
        settings.texture_resolution,
    )
    if band_width <= 0.0:
        _CACHE.pop(scene.as_pointer(), None)
        return False
    sources = _collect_sources_for_scene(scene)
    before = _CACHE.get(scene.as_pointer())
    before_revision = before.revision if before is not None else -1
    before_pending = before.pending_positions if before is not None else None
    entry = _ensure_entry(
        scene,
        sources,
        band_width,
        settings.selected_only,
        bool(scene.tool_settings.use_uv_select_sync),
    )
    return (
        before is None
        or entry.revision != before_revision
        or entry.pending_positions is not before_pending
    )


def _update_timer():
    """Coalesce dependency updates without re-entering BMesh from draw code."""

    if not _REGISTERED:
        return None
    changed = False
    try:
        window_manager = getattr(bpy.context, "window_manager", None)
        scenes = {}
        if window_manager is not None:
            for window in window_manager.windows:
                scene = window.scene
                scenes[scene.as_pointer()] = scene
        for scene in scenes.values():
            try:
                changed = _update_scene_cache(scene) or changed
            except (ReferenceError, RuntimeError, ValueError):
                _CACHE.pop(scene.as_pointer(), None)
        if changed:
            tag_uv_editors_for_redraw()
    except Exception:
        # A timer must never destabilize Blender. Unexpected state is retried
        # after the current editor operation has completed.
        _CACHE.clear()
    if time.monotonic() - _LAST_INVALIDATION < _IDLE_VERIFY_DELAY:
        return _UPDATE_INTERVAL
    return _IDLE_INTERVAL


def _ensure_update_timer():
    if not _REGISTERED:
        return
    if not bpy.app.timers.is_registered(_update_timer):
        bpy.app.timers.register(
            _update_timer,
            first_interval=0.0,
            persistent=True,
        )


@persistent
def _depsgraph_update_post(_scene, depsgraph):
    relevant = False
    for update in depsgraph.updates:
        data = update.id
        if isinstance(data, bpy.types.Mesh):
            relevant = True
            break
        if isinstance(data, bpy.types.Object) and data.type == "MESH":
            relevant = True
            break
    if relevant:
        invalidate_geometry()


@persistent
def _reset_after_file_change(_unused):
    invalidate_geometry(clear=True)
    _ensure_update_timer()


def _append_handler(collection, handler):
    if handler not in collection:
        collection.append(handler)


def _remove_handler(collection, handler):
    if handler in collection:
        collection.remove(handler)


def register():
    global _DRAW_HANDLE, _REGISTERED
    _REGISTERED = True
    if _DRAW_HANDLE is None:
        _DRAW_HANDLE = bpy.types.SpaceImageEditor.draw_handler_add(
            _draw_overlay,
            (),
            "WINDOW",
            "POST_VIEW",
        )
    _append_handler(bpy.app.handlers.depsgraph_update_post, _depsgraph_update_post)
    _append_handler(bpy.app.handlers.undo_post, _reset_after_file_change)
    _append_handler(bpy.app.handlers.redo_post, _reset_after_file_change)
    _append_handler(bpy.app.handlers.load_post, _reset_after_file_change)
    _ensure_update_timer()
    invalidate_geometry(clear=True)


def unregister():
    global _DRAW_HANDLE, _SHADER, _REGISTERED
    _REGISTERED = False
    if bpy.app.timers.is_registered(_update_timer):
        bpy.app.timers.unregister(_update_timer)
    _remove_handler(bpy.app.handlers.load_post, _reset_after_file_change)
    _remove_handler(bpy.app.handlers.redo_post, _reset_after_file_change)
    _remove_handler(bpy.app.handlers.undo_post, _reset_after_file_change)
    _remove_handler(bpy.app.handlers.depsgraph_update_post, _depsgraph_update_post)
    if _DRAW_HANDLE is not None:
        bpy.types.SpaceImageEditor.draw_handler_remove(_DRAW_HANDLE, "WINDOW")
        _DRAW_HANDLE = None
    _CACHE.clear()
    _SHADER = None
    tag_uv_editors_for_redraw()

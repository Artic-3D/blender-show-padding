"""UV Padding Overlay Blender extension."""

from . import overlay, settings, ui


def register():
    settings.register()
    ui.register()
    overlay.register()


def unregister():
    overlay.unregister()
    ui.unregister()
    settings.unregister()

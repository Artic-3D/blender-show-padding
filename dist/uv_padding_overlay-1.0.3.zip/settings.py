"""Persistent scene settings for UV Padding Overlay."""

import bpy
from bpy.props import BoolProperty, FloatProperty, FloatVectorProperty, IntProperty
from bpy.types import PropertyGroup


def _geometry_update(_settings, _context):
    from . import overlay

    overlay.invalidate_geometry()


def _style_update(_settings, _context):
    from . import overlay

    overlay.tag_uv_editors_for_redraw()


class UVPADDING_PG_settings(PropertyGroup):
    enabled: BoolProperty(
        name="Show Padding",
        description="Display padding around visible UV shells",
        default=True,
        update=_geometry_update,
    )
    margin_px: FloatProperty(
        name="Margin",
        description="Desired total gap between adjacent UV shells, in texture pixels",
        default=8.0,
        min=0.0,
        soft_max=128.0,
        precision=2,
        update=_geometry_update,
    )
    texture_resolution: IntProperty(
        name="Texture Resolution",
        description="Square texture resolution used to convert pixels to UV units",
        default=2048,
        min=1,
        soft_min=64,
        soft_max=16384,
        update=_geometry_update,
    )
    selected_only: BoolProperty(
        name="Selected Only",
        description="Show complete UV shells touched by the current UV selection",
        default=False,
        update=_geometry_update,
    )
    color: FloatVectorProperty(
        name="Color",
        description="Overlay color; opacity is fixed at 50 percent",
        subtype="COLOR",
        size=3,
        min=0.0,
        max=1.0,
        default=(1.0, 0.05, 0.35),
        update=_style_update,
    )


_CLASSES = (UVPADDING_PG_settings,)


def register():
    for cls in _CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.Scene.uv_padding_overlay = bpy.props.PointerProperty(
        type=UVPADDING_PG_settings
    )


def unregister():
    if hasattr(bpy.types.Scene, "uv_padding_overlay"):
        del bpy.types.Scene.uv_padding_overlay
    for cls in reversed(_CLASSES):
        bpy.utils.unregister_class(cls)
